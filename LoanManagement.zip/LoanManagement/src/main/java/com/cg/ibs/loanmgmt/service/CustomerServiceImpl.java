package com.cg.ibs.loanmgmt.service;

import java.math.BigDecimal;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.bean.LoanTypeBean;
import com.cg.ibs.loanmgmt.dao.CustomerDao;
import com.cg.ibs.loanmgmt.dao.CustomerDaoImpl;
import com.cg.ibs.loanmgmt.dao.LoanTypeDao;
import com.cg.ibs.loanmgmt.dao.LoanTypeDaoImpl;

public class CustomerServiceImpl implements CustomerService {
	LoanTypeDao loanTypeDao = new LoanTypeDaoImpl();
	CustomerDao customerDao = new CustomerDaoImpl();

	@Override
	public LoanTypeBean getLoanType(Integer typeId) {
		return loanTypeDao.getLoanType(typeId);
	}

	@Override
	public boolean verifyLoanAmount(BigDecimal loanAmount, BigDecimal maximumLimit, BigDecimal minimumLimit) {
		boolean verify = false;
		if (loanAmount.compareTo(maximumLimit) < 0 && loanAmount.compareTo(minimumLimit) > 0) {
			verify = true;
		}
		return verify;
	}

	@Override
	public boolean verifyLoanTenure(int tenure) {
		boolean verify = false;
		if (tenure > 0 && (tenure % 6 == 0)) {
			verify = true;
		}
		return verify;
	}

	@Override
	public LoanMaster calculateEmi(LoanMaster loanMaster) {
		Float rate = loanTypeDao.getLoanType(loanMaster.getTypeId()).getInterestRate() / (12 * 100);
		Double onePlusRPoweredN = Math.pow((rate + 1), loanMaster.getLoanTenure());
		BigDecimal principal = loanMaster.getLoanAmount();
		BigDecimal emi = principal.multiply(BigDecimal.valueOf((rate * onePlusRPoweredN) / (onePlusRPoweredN - 1)));
		loanMaster.setEmiAmount(emi.setScale(2, BigDecimal.ROUND_UP));
		return loanMaster;
	}

	@Override
	public boolean verifyCustomerLogin(String userId, String password) {
		boolean login= false;
		CustomerBean customer = customerDao.getCustomerByUserId(userId);
		if(null!= customer && password.equals(customer.getPassword())) {
			login = true;
		}
		return login;
	}

	@Override
	public CustomerBean getCustomer(String userId) {
		return customerDao.getCustomerByUserId(userId);
	}

	@Override
	public boolean applyLoan(CustomerBean customer, LoanMaster loanMaster, String path) {
		
		return false;
	}

}
