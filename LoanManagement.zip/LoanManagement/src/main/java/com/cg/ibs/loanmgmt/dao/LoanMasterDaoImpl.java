package com.cg.ibs.loanmgmt.dao;

public class LoanMasterDaoImpl implements LoanMasterDao{

}
