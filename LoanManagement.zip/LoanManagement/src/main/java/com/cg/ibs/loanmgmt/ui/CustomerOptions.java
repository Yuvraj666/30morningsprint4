package com.cg.ibs.loanmgmt.ui;

public enum CustomerOptions {
	APPLY_LOAN, PAY_EMI, APPLY_PRECLOSURE, VIEW_HISTORY, LOG_OUT
}
