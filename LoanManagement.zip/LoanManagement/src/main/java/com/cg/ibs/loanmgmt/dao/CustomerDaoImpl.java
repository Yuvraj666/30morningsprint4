package com.cg.ibs.loanmgmt.dao;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.util.JpaUtil;

public class CustomerDaoImpl implements CustomerDao {
	private EntityManager entityManager;

	public CustomerDaoImpl() {
		entityManager = JpaUtil.getEntityManger();
	}

	@Override
	public CustomerBean getCustomerByUserId(String userId) {
		CustomerBean customer = new CustomerBean();
		TypedQuery<CustomerBean> query = entityManager.createQuery("select c from CustomerBean c where c.userId=?1", CustomerBean.class);
		query.setParameter(1, userId);
		customer = (CustomerBean) query.getSingleResult();
		return customer;
	}

}
